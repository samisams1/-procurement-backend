import Quotation from './resolvers';

export { Quotation};