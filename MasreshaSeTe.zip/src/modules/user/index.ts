import User from './model';
import resolvers from './resolver';
import typeDefs from './schema';

export { User, resolvers, typeDefs };