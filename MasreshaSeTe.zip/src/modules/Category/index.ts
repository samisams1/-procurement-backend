import Category from './model';
import resolvers from './resolver';
import typeDefs from './schema'
export {Category,resolvers, typeDefs};